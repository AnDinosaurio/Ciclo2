package utp.misiontic2022.c2.p07.reto4.model.vo;

public class Requerimiento_2 {
     // Operaciones de la clase requerimiento 2 -- su código   
}
