package utp.misiontic2022.c2.p07.reto4.view;

import java.util.ArrayList;

import utp.misiontic2022.c2.p07.reto4.controller.ControllerRequerimientos;

import utp.misiontic2022.c2.p07.reto4.model.vo.Requerimiento_1;
import utp.misiontic2022.c2.p07.reto4.model.vo.Requerimiento_2;
import utp.misiontic2022.c2.p07.reto4.model.vo.Requerimiento_3;


public class ViewRequerimientos {

    public static final ControllerRequerimientos controlador = new ControllerRequerimientos();

    public static void requerimiento1(){
        try {
            // Su código
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    public static void requerimiento2(){
        try {
            // Su código
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    public static void requerimiento3(){
        try {
            // Su código
        } catch (Exception e) {
            System.err.println(e);
        }
    }
    
}

