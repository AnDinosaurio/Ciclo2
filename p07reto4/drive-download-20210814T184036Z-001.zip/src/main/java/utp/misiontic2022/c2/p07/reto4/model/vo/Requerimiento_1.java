package utp.misiontic2022.c2.p07.reto4.model.vo;

public class Requerimiento_1 {
    // Operaciones de la clase requerimiento 1 -- su código
}
