package utp.misiontic2022.c2.p07.reto4.model.vo;

public class Requerimiento_3 {
     // Operaciones de la clase requerimiento 3 -- su código
}
