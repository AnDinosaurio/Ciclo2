package utp.misiontic2022.c2.p07.reto4.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import utp.misiontic2022.c2.p07.reto4.model.dao.RequerimientoDao_1;
import utp.misiontic2022.c2.p07.reto4.model.dao.RequerimientoDao_2;
import utp.misiontic2022.c2.p07.reto4.model.dao.RequerimientoDao_3;
import utp.misiontic2022.c2.p07.reto4.model.vo.Requerimiento_1;
import utp.misiontic2022.c2.p07.reto4.model.vo.Requerimiento_2;
import utp.misiontic2022.c2.p07.reto4.model.vo.Requerimiento_3;

public class ControllerRequerimientos {
        // Su código
    
        public ArrayList<Requerimiento_1> consultarRequerimiento1() throws SQLException {
            // Su código
            return null;
        }
    
        public ArrayList<Requerimiento_2> consultarRequerimiento2() throws SQLException {
            // Su código
            return null;
        }
    
        public ArrayList<Requerimiento_3> consultarRequerimiento3() throws SQLException {
            // Su código
            return null;
        }

    
}
